# File:     depth_first_search.py
# Authors: Lucas Duarte Bahia,Jordan Giebas,Harveen Oberoi,Daniel Rojas Coy

import pandas as pd

def DFS(G, cur, S=None):  
    if S is None:
        S = set()
    
    if cur not in S:       
        S.add(cur)
        for v in G[cur]:
            DFS(G, v, S)

    return(S)
         

def con_comps_of(G):
    total = set(G.keys())
    comp = list()
    while len(total)>0:
        temp = DFS(G, total.pop())
        total = total.difference(temp)
        comp.append(temp)
    return(comp)
        
    
    

def main():
    G2 = { 'A' : [ 'B', 'D' ],
           'B' : [ 'A' ],
           'C' : [ 'E' ],
           'D' : [ 'A' ],
           'E' : [ 'C' ],
           'F' : [] }

    print("G2 connected components are:\n", con_comps_of(G2))
    
    G = { 'A' : [ 'B', 'J', 'Me' ],
         'B' : [ 'A' ],
         'C' : [ 'D', 'P' ],
         'D' : [ 'C', 'O' ],
         'E' : [ 'F', 'J', 'K' ],
         'F' : [ 'E', 'M' ],
         'G' : [ 'K', 'S', 'Ed' ],
         'H' : [ 'O', 'U' ],
         'Me': [ 'A', 'I', 'N', 'V' ],
         'I' : [ 'Me', 'Q' ],
         'J' : [ 'A', 'E', 'L', 'Q', 'W' ],
         'K' : [ 'E', 'G' ],
         'L' : [ 'J', 'W' ],
         'M' : [ 'E', 'S', 'T' ],
         'N' : [ 'Me', 'V' ],
         'O' : [ 'H', 'D' ],
         'P' : [ 'C', 'U' ],
         'Q' : [ 'I', 'J', 'X', 'Y' ],
         'R' : [ 'Ed' ],
         'S' : [ 'G', 'M', 'Y', 'Z' ],
         'T' : [ 'M' ],
         'U' : [ 'H', 'P' ],
         'V' : [ 'Me', 'N' ],
         'W' : [ 'J', 'L' ],
         'X' : [ 'Q', 'Y' ],
         'Y' : [ 'Q', 'S', 'X', 'Z' ],
         'Ed': [ 'G', 'R', 'Z' ],
         'Z' : [ 'S', 'Y', 'Ed' ] }
    
    print("G connected components are:\n", con_comps_of(G))
    
    ################
    
    data = pd.read_csv("D:/CMU_GD/Mini 4/Financial Computing III/Homeworks/HW4/links.csv")

    dd = dict.fromkeys(data.values[:,1])
    
    for k in dd.keys():
        links =  data.values[k==data.values[:,1],0]
        temp = set()
        for x in links:
            temp = temp.union(set(list(data.values[data.values[:,0]==x,1])).difference({k}))
        
        dd[k] = list(temp)
    
    conco_dd = con_comps_of(dd)
    print("link.csv connected components are:\n", conco_dd)
    print("There are ", len(conco_dd), " connected components")
    print("The largest connected component is:\n", conco_dd[0] )
    print("The smallest connected component is:\n", conco_dd[1] )


if __name__ == "__main__":
    main()
