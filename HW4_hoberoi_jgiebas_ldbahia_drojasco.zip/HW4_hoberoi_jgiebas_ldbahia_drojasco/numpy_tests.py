#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 15 17:58:26 2018

@author: Harveen Oberoi, Lucas Duarte Bahia, Daniel Rojas Coy, Jordan Giebas
"""

# Question 2(a)

import numpy as np

def main():
    print("hello, numpy_tests.py")
    
    ## Question 2(b)
    an1 = np.random.randn(5,5).round(3)
    print("\n")
    print("an1:")
    print("\n")
    print(an1)
    
    ## Question 2(c)
    an2 = np.random.randn(5,5).round(3)
    print("\n")
    print("an2:")
    print("\n")
    print(an2)
    
    ## Question 2(d)
    np.random.seed(0)
    an3 = np.random.randn(5,5).round(3)
    print("\n")
    print("an4:")
    print("\n")
    print(an3)
    
    np.random.seed(0)
    an4 = np.random.randn(5,5).round(3)
    print("\n")
    print("an4:")
    print("\n")
    print(an4)
    
    ## CHECK THIS!!!! ##
    print("\n")
    print("ID for an3:",id(an3))
    print("ID for an4:",id(an4))
    
    ## The both are not the same impying that they are not a reference to the same object.
    
    ## Question 2(e)
    an3[2,:] += 3.3
    print("\n")
    print("Modified an3:")
    print("\n")
    print(an3)
    
    ##Question 2(f)
    an3[:,0] = -an3[:,0]
    print("\n")
    print("Modified an3:")
    print("\n")
    print(an3)
    
    ##Question 2(g)
    an3[1:4,1:4] = np.identity(3)
    print("\n")
    print("Modified an3:")
    print("\n")
    print(an3)
    
    ##Question 2(h)
    an5 = an3[3:5,3:5].copy()
    an5 = an5*2.2
    print("\n")
    print("an5:")
    print("\n")
    print(an5)
    
    print("\n")
    print("an3")
    print("\n")
    print(an3)
    
    ##Question 2(i)
    print("\n")
    print("Shape of an3:", an3.shape)
    
    print("\n")
    print("Dimensions of an3:", an3.ndim)
    
    print("\n")
    print("Data Type of an3:", type(an3))
    
    print("\n")
    print("Type of upper left element of an3:", type(an3[0,4]))
    
    ##Question 2(j)
    brows=[True,False,True,False,True]
    an3[brows] -=1.1
    print("\n")
    print("Modified an3:")
    print("\n")
    print(an3)
    
    ##Question 2(k)
    an3[(an3>1.0) | (an3<-1.0)] = 0.333
    print("\n")
    print("Modified an3:")
    print("\n")
    print(an3)
    
    ##Question 2(l)
    an3 = an3[[4,3,2,1,0],:]
    print("\n")
    print("Modified an3:")
    print("\n")
    print(an3)
    
    ##Question 2(m)
    an3[:,[1,3]] = an3[:,[3,1]]
    print("\n")
    print("Modified an3:")
    print("\n")
    print(an3)
    
    ##Question 2(n)
    print("\n")
    print("Maximum of an3:",np.max(an3))
    print("\n")
    print("Minimum of an3:",np.min(an3))
    print("\n")
    print("Mean of an3:",np.mean(an3))
    print("\n")
    print("Sum of an3:",np.sum(an3))
    print("\n")
    print("Variance of an3:",np.var(an3))
    print("\n")
    print("Standard Deviation of an3:",np.std(an3))
    
    
    ##Question 2(o)
    import numpy.linalg as la
    an3trans = an3.T
    print("\n")
    print("Transpose of an3:")
    print("\n")
    print(an3trans)
    
    ##Question 2(p)
    an3sqr = an3.dot(an3trans)
    print("\n")
    print("Square of an3:")
    print("\n")
    print(an3sqr)
    
    ##Question 2(q)
    det_an3 = la.det(an3)
    det_an3trans = la.det(an3trans)
    det_an3sqr = la.det(an3sqr)
    print("\n")
    print("Determinant of an3:")
    print(det_an3)
    
    print("\n")
    print("Determinant of an3T:")
    print(det_an3trans)
    
    print("\n")
    print("Determinant of an3 square:")
    print(det_an3sqr)
    
    ## The values makes sense because the determinants of a square matrix and its
    ## transpose are equal. The determinnat of the square of the matrix is 
    ## square of the determinants. The values cofer mathematically.
    
    ##Question 2(r)
    an3inv  = la.inv(an3)
    print("\n")
    print("Inverse of an3:")
    print("\n")
    print(an3inv)
    
    ##Question 2(s)
    product_mat = an3.dot(an3inv).round(10)
    print("\n")
    print("product of an3 and its inverse:")
    print("\n")
    print(product_mat)
    ##The values make absolute sense wince product of a matrix and it inverse should be 
    ## the identity matrix which is confirmed by the values displayed.
    
    
    ##Question 2(t)
    b = np.array([1,1,1,1,1])
    print(b)
    
    ##Question 2(u)
    x = la.solve(an3,b)
    print("\n")
    print("x which solves an3.x=b:")
    print("\n")
    print(x)
    
    ##Question 2(v)
    x2 = la.solve(an3inv,x).round(10)
    print("\n")
    print("x2 which solves an3inv.x2=x:")
    print(x2)
    ##The values confer that x2=b
    
    
    
    
    
    
    
    
    

if __name__ == '__main__':
    main()
    
