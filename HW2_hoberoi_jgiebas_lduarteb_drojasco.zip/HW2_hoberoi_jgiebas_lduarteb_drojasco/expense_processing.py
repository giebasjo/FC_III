#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  2 00:47:31 2018

@author: Harveen Oberoi (hoberoi), Jordan Giebas (jgiebas), Lucas Duarte Bahia (lduarteb), Daniel Rojas Coy (drojasco)
"""
#fout = open("records.txt","w")

## Question 1(a)
fin = open("expenses.txt","rt")
records=[]
for line in fin:
    records.append(line)
    
    
for line in records:
   print(line)

fin.close()

## Question 1(b)
fin = open("expenses.txt","rt")
records2 = [line for line in fin]
print("\nrecords == records2:",
records == records2, '\n')

## Question 1(c)
fin.close()
fin = open("expenses.txt","rt")
records3 = tuple(tuple(rec.split(":")) for rec in fin)
for tup in records3:
		    print(tup) 
          
## Question 1(d)
cat_set = {tup[1] for tup in records3[1:len(records3)]}    
print('Categories:', cat_set, '\n')
       
dat_set = {tup[2] for tup in records3[1:len(records3)]}
print('Dates:', dat_set, '\n')

## Question 1(e)
aux_records = tuple(line for line in records)
rec_num_to_record = dict(zip(range(len(aux_records)), aux_records))

for rn in range(len(rec_num_to_record)):
		    print('{:3d}: {}'.format(rn,rec_num_to_record[rn]))

