#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  4 23:11:47 2018

@author: Harveen Oberoi (hoberoi), Jordan Giebas (jgiebas), Lucas Duarte Bahia (lduarteb), Daniel Rojas Coy (drojasco)

"""

import EuroCallOption as ecpm
import BinaryTree as bt
import random

def main():
    random.seed(0)  # we want repeatable results

    # Euro Call pricing test
    ec = ecpm.EuropeanCallOption(
                                50.0, 40.0, 0.1, 0.3, 0.5)
    for steps in [10,100,1000]:
        print('Call price', steps, 'steps: ',
              round(ec.binomialPrice(steps), 4))

    # Binarytree tests
    bt1 = bt.BinaryTree()
    bt2 = bt.BinaryTree()
    for i in range(25):
        # random integer in [-10..10]
        bt1.insert(random.randint(-11,10))
        bt2.insert(random.randint(-11,10))
    print("bt1:", bt1)
    print("bt2:", bt2)
    print("bt1 pretty:")
    bt1.print_pretty()
    print("bt2 pretty:")
    bt2.print_pretty()
    
    bt3 = bt.BinaryTree()
    bt3.insert(1)
    bt4 = bt.BinaryTree()
    bt4.insert(1)
    
    if bt1==bt2:
        print("bt1 and bt2 are equal")
    else:
        print("bt1 and bt2 are not equal")

if __name__ == '__main__':
    main()
    


