#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  4 19:04:22 2018

@author: Harveen Oberoi(hoberoi), Jordan Giebas (jgiebas), Lucsa Duarte Bahia (lduarteb), Daniel Rojas Coy (drojasco)
"""
## Question 2(a)
import re
fin = open("expenses.txt","rt")
records=[]

for line in fin:
    records.append(line)
    
fin.close()

## Q2(a)
#pat = r'D'

## Q2(b)
#pat = r'\''

## Q2(c)
#pat = r'\"'

## Q2(d)
#pat = r'^7'

## Q2(e)
#pat = r'[rt]$'

## Q2(f)
#pat = r'\.'

## Q2(g)
#pat = r'r.*g'

## Q2(h)
#pat = r'[A-Z][A-Z]'

## Q2(i)
#pat = r'\,'

## Q2(j)
#pat = r'\,.*\,.*\,'   

## Q2(k)
#pat = r'^[^v-z]*$'

## Q2(l)
#pat = r'^[1-9][0-9]\.[0-9][0-9]'

## Q2(m)
#pat = r'^[^,]*,[^,]*,[^,]*,[^,]*$'

## Q2(n)
#pat = r'\('

## Q2 (o)
#pat = r'^[1-9][0-9][0-9]'

## Q2 (p)
#pat=r'.*:\w{4}:.*'

## Q2 (q)
#pat= r'201703[0-3][0-9]'

## Q2 (r)
# No records for a,b,c. Trying with A,B,C
#pat = r'^[^bc]*a[^c]*b.*c.*$'
#pat= r'^[^BC]*A[^C]*B.*C.*$'

## Q2 (s)
#pat = r'(..).*\1.*\1'

## Q2 (t)
#pat = r'^.*\:.*\:.*\:.*([a-z].*[0-9]|[0-9].*[a-z]).*$'

## Q2 (u)
#pat = r'^[^A-Z]*$'

## Q2 (v)
#pat = r'd.?i'
for line in records:
		    if re.search(pat, line) != None:
		        print(line)
