# file float_regex.py
# Author(s): Lucas Duarte Bahia, Jordan Giebas, Harveen Oberoi,Daniel Rojas Coy

        
float_tests = [
    '0',        # int, not float
    '.',        # not float
    '0.',       # float
    '3e3',      # float
    'e3',       # not float
    '7e',       # not float
    '.e7',      # not float
    '.0',       # float
    '5.5',      # float
    '123e-0',   # float
    '12e+4',    # float
    '+1.',      # float
    '-0.',      # float
    '-.4',      # float
    '-.e4',     # not float
    '+1.5.5',   # not float
    '+34.12e04', # float
    '+7.-4',    # not float
    '1.e+1e1',  # not float
    '.0e0',     # float
    '.0000123', # float
    '12341234.12341234E+12341234',  # float
    '23E-1',    # float
    '.1E+',     # not float
    '2.2e-',    # not float
    '-0.E+22',  # float
    '-4E-.23',  # not float
    '12e0',     # float
    '12.0e0',   # float
    '12.0',     # float
    '+12e+2',   # float
    '+12+e3',   # not float
    '.4321e123', # float
    '.432e+12', # float
    '.432e-00', # float
    '.432e12.', # not float
    '43e-23.',  # not float
    'eeee'      # not float
]

# your code goes here

import re

pat='^[+-]{0,1}(?:(?:[0-9]+(?:\.|[eE][+-]*[0-9]+|\.[eE][+-]*[0-9]+)$)|(?:\.[0-9]+(?:[eE][+-]*[0-9]+)*$)|(?:[0-9]+\.[0-9]+(?:[eE][+-]*[0-9]+)*$))'
#expo = '[eE][+-]*[0-9]+$'

for line in float_tests:
    if re.search(pat, line) != None:
        print(line + " is a valid float literal")
    else:
        print(line + " is NOT valid float literal")

######################################
# Test
######################################

def try_float(s):
    try:
        float(s)
        return(1)
    except:
        return(0)
        
boo = [try_float(x) for x in float_tests]
boo[0] = 0         
         

test= []
for line in float_tests:
    if re.search(pat, line) != None:
        test.append(1)
    else:
        test.append(0)
 
test == boo